# PSxxxxx3010

**Mô tả (VN):**

Dự án mẫu mở đơn giản tên **PSxxxxx3010**. Đây là kho khởi đầu (starter) chứa ví dụ mã nguồn Python, hướng dẫn cài đặt và hướng dẫn cấp phép bằng GPL-2.0.

**Description (EN):**

A simple starter open-source project named **PSxxxxx3010**. Includes sample Python code, installation instructions, and guidance for applying the GPL-2.0 license.

## Files
- `src/main.py` — sample Python script.
- `README.md` — this file.
- `.gitignore` — common ignores.
- `LICENSE` — *not included here*; see instructions below to add GNU GPL v2.0 to the repository using GitHub or gh CLI.

## How to publish to GitHub (quick)
1. Install Git and (optionally) GitHub CLI `gh`.
2. In this folder run:

```bash
git init
git add .
git commit -m "Initial commit"
# create remote repo (using gh):
gh repo create PSxxxxx3010 --public --source=. --remote=origin --push --license "gpl-2.0"
```

If you prefer the GitHub web UI: create a new repository named **PSxxxxx3010** and choose **GNU General Public License v2.0** during creation, then push your local repo as remote `origin`.

## Notes about the LICENSE
The GPL-2.0 full text is not included in this archive to avoid verbatim license copying here. When you create the GitHub repo using `gh` with `--license "gpl-2.0"`, GitHub will add the full GPL-2.0 text automatically. Alternatively, you can copy the full text from the official GNU site: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html

## Contributing
- Fork, create a branch, open a PR.
- Keep commits focused and include tests where appropriate.

---

If you want, I can include the full `LICENSE` file text in the archive too (I didn't include it automatically).