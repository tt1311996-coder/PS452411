"""Simple example script for PSxxxxx3010."""
import sys

def greet(name: str = "world") -> str:
    return f"Hello, {name} from PSxxxxx3010!"

def main():
    name = sys.argv[1] if len(sys.argv) > 1 else "world"
    print(greet(name))

if __name__ == "__main__":
    main()
